import subprocess
import re
import time
import sys

try:
    from colorama import init, Fore
    init(autoreset=True)
    use_color = True
except:
    use_color = False

def print_red(msg):
    if use_color:
        print(Fore.RED + msg)
    else:
        print(msg)

def print_green(msg):
    if use_color:
        print(Fore.GREEN + msg)
    else:
        print(msg)

def print_cyan(msg):
    if use_color:
        print(Fore.CYAN + msg)
    else:
        print(msg)

def send_ping(host):
    try:
        cmd = ["ping", "-n", "1", host]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)

        if result.returncode == 0:
            match = re.search(r"time[=<](\d+\.?\d*)\s*ms", result.stdout, re.IGNORECASE)
            if match:
                latency = float(match.group(1))
                return True, latency
            else:
                return True, None
        else:
            return False, None

    except subprocess.TimeoutExpired:
        return False, None
    except:
        return False, None

def main():
    target = input("Enter target server address (example: 8.8.8.8): ").strip()

    if target == "":
        print_red("Invalid address")
        return

    print(f"\nStarting network test to {target}")
    print("Sending ping every 5 seconds. Total 10 times.")
    print("-" * 50)

    ping_results = []

    for x in range(1, 11):
        print(f"[{x}/10] Sending ping to {target} ...")
        ok, delay = send_ping(target)

        if ok and delay is not None:
            print_green(f"OK - Response received | Latency: {delay:.2f} ms")
            ping_results.append(delay)
        else:
            print_red("FAIL - Packet Loss | No response from server")

        if x < 10:
            time.sleep(5)

    print("\n" + "=" * 50)

    if len(ping_results) > 0:
        average = sum(ping_results) / len(ping_results)
        print_cyan(f"Average Latency: {average:.2f} ms")

        if len(ping_results) >= 3:
            mean_val = average
            total = 0
            for val in ping_results:
                total = total + ((val - mean_val) ** 2)
            variance = total / (len(ping_results) - 1)
            std = variance ** 0.5

            bad_count = 0
            for val in ping_results:
                if abs(val - mean_val) > 2 * std:
                    bad_count = bad_count + 1

            if bad_count > len(ping_results) * 0.3:
                print_red("WARNING: Network is unstable or abnormal")
            else:
                print_green("Network status is stable")
    else:
        print_red("No response received - Cannot calculate average")

    print("\nProcess finished")

if __name__ == "__main__":
    main()
