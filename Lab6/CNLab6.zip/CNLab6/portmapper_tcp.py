import socket
import threading

HOST = "127.0.0.1"
PORT = 9999

services = {}

def handle_client(conn, addr):
    try:
        data = conn.recv(1024).decode('utf-8')
        print(f"Received: {data} from {addr}")
        
        parts = data.split()
        if parts[0] == "REGISTER" and len(parts) == 3:
            name, port = parts[1], int(parts[2])
            services[name] = port
            conn.send(f"OK {name} registered on {port}".encode())
        elif parts[0] == "LOOKUP" and len(parts) == 2:
            name = parts[1]
            if name in services:
                conn.send(f"PORT {services[name]}".encode())
            else:
                conn.send("NOT_FOUND".encode())
        else:
            conn.send("ERROR".encode())
        conn.close()
    except:
        pass

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(5)
print(f"Port Mapper (TCP) running on {HOST}:{PORT}")

while True:
    conn, addr = server.accept()
    threading.Thread(target=handle_client, args=(conn, addr)).start()