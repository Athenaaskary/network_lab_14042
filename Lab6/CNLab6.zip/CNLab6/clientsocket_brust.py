import socket
import threading
import time

HOST = "127.0.0.1"
PORT = 5000
BURST_SOCKETS = 50

def send_request(i):
    try:
        msg = f"Request {i}"
        
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(5)
        
        start = time.perf_counter()
        client.connect((HOST, PORT))
        
        client.send(msg.encode('utf-8'))
        
        data = client.recv(1024)
        response = data.decode('utf-8')
        
        delay = (time.perf_counter() - start) * 1000
        print(f"Request {i}: {response} - delay: {delay:.2f}ms")
        
        client.close()
        
    except ConnectionRefusedError:
        print(f"Request {i}: Server not available")
    except socket.timeout:
        print(f"Request {i}: Connection timeout")
    except Exception as e:
        print(f"Request {i}: Error - {e}")

print(f"Sending {BURST_SOCKETS} burst requests...")
start_time = time.time()

for i in range(BURST_SOCKETS):
    t = threading.Thread(target=send_request, args=(i,))
    t.start()

time.sleep(30)
print(f"All requests sent. Total time: {time.time() - start_time:.2f}s")