import socket
import time

HOST = "127.0.0.1"
PORT = 5000

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

for i in range(5):
    message = f"Request {i+1}: What is the time?"
    client.sendto(message.encode('utf-8'), (HOST, PORT))
    print(f"Sent: {message}")
    
    client.settimeout(2)
    try:
        data, addr = client.recvfrom(1024)
        print(f"Received: {data.decode('utf-8')}\n")
    except socket.timeout:
        print("No response from server (timeout)\n")
    
    time.sleep(1)

client.close()