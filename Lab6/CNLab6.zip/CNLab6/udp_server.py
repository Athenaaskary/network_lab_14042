import socket
import time

HOST = "127.0.0.1"
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))
print(f"UDP Time Server is running on {HOST}:{PORT}")

while True:
    data, addr = server.recvfrom(1024)
    print(f"Request received from {addr}")
    
    current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    message = f"Server Time: {current_time}"
    
    server.sendto(message.encode('utf-8'), addr)
    print(f"Time sent to {addr}: {current_time}")