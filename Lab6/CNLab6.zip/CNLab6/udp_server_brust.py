import socket
import time
import threading

HOST = "127.0.0.1"
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))
print(f"UDP Server running on {HOST}:{PORT}")

def process_request(data, addr):
    time.sleep(1)
    response = f"Processed: {data.decode('utf-8')}"
    server.sendto(response.encode('utf-8'), addr)

while True:
    try:
        data, addr = server.recvfrom(1024)
        print(f"Request from {addr}")
        threading.Thread(target=process_request, args=(data, addr)).start()
    except KeyboardInterrupt:
        break

server.close()