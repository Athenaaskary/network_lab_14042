import socket

HOST = "127.0.0.1"
PORT_MAPPER = 9999

temp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
temp.bind((HOST, 0))
SERVICE_PORT = temp.getsockname()[1]
temp.close()

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT_MAPPER))
client.send(f"REGISTER ECHO {SERVICE_PORT}".encode())
print(client.recv(1024).decode())
client.close()

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, SERVICE_PORT))
server.listen(5)
print(f"Echo Service running on port {SERVICE_PORT}...")

while True:
    conn, addr = server.accept()
    data = conn.recv(1024)
    conn.send(data)
    conn.close()