import socket
import threading
import time

HOST = "127.0.0.1"
PORT_MAPPER_PORT = 9999

services = {}

def handle_client(data, addr, server_socket):
    try:
        request = data.decode('utf-8').split()
        
        if request[0] == "REGISTER":
            service_name = request[1]
            service_port = int(request[2])
            services[service_name] = service_port
            response = f"REGISTERED {service_name} on port {service_port}"
            print(f"Registered: {service_name} -> {service_port}")
            
        elif request[0] == "LOOKUP":
            service_name = request[1]
            if service_name in services:
                response = f"PORT {services[service_name]}"
                print(f"Lookup: {service_name} -> {services[service_name]}")
            else:
                response = "NOT_FOUND"
                print(f"Lookup: {service_name} not found")
        else:
            response = "ERROR Invalid command"
        
        server_socket.sendto(response.encode('utf-8'), addr)
        
    except Exception as e:
        print(f"Error handling client: {e}")

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT_MAPPER_PORT))
print(f"Port Mapper running on {HOST}:{PORT_MAPPER_PORT}")

while True:
    try:
        data, addr = server.recvfrom(1024)
        thread = threading.Thread(target=handle_client, args=(data, addr, server))
        thread.start()
    except ConnectionResetError:
        print("Connection reset by client - ignoring")
        continue
    except Exception as e:
        print(f"Unexpected error: {e}")
        continue