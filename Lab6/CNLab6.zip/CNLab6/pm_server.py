import socket
import time

HOST = "127.0.0.1"
PORT_MAPPER_PORT = 9999

temp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
temp_socket.bind((HOST, 0))
SERVICE_PORT = temp_socket.getsockname()[1]
temp_socket.close()

print(f"Service will run on port {SERVICE_PORT}")

mapper_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
mapper_client.sendto(f"REGISTER ECHO_SERVICE {SERVICE_PORT}".encode('utf-8'), (HOST, PORT_MAPPER_PORT))
mapper_client.close()
print("Registered with Port Mapper")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, SERVICE_PORT))
server.listen(5)
print(f"Echo Service running on port {SERVICE_PORT}...")

while True:
    client_socket, addr = server.accept()
    data = client_socket.recv(1024)
    client_socket.send(data)
    client_socket.close()