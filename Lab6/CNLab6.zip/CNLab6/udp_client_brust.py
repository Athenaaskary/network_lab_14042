import socket
import threading
import time

HOST = "127.0.0.1"
PORT = 5000
BURST_SOCKETS = 50

def send_request(i):
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client.settimeout(2)
        
        msg = f"Request {i}"
        start = time.perf_counter()
        
        client.sendto(msg.encode('utf-8'), (HOST, PORT))
        
        try:
            data, addr = client.recvfrom(1024)
            delay = (time.perf_counter() - start) * 1000
            print(f"Request {i}: {data.decode('utf-8')} - delay: {delay:.2f}ms")
        except socket.timeout:
            print(f"Request {i}: No response (timeout)")
        
        client.close()
    except Exception as e:
        print(f"Request {i}: Error - {e}")

print(f"Sending {BURST_SOCKETS} UDP burst requests...")
start_time = time.time()

for i in range(BURST_SOCKETS):
    t = threading.Thread(target=send_request, args=(i,))
    t.start()

time.sleep(10)
print(f"Total time: {time.time() - start_time:.2f}s")