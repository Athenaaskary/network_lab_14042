import socket

HOST = "127.0.0.1"
PORT_MAPPER_PORT = 9999

mapper_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
mapper_client.sendto(b"LOOKUP ECHO_SERVICE", (HOST, PORT_MAPPER_PORT))
mapper_client.settimeout(2)

try:
    data, addr = mapper_client.recvfrom(1024)
    response = data.decode('utf-8')
    print(f"Port Mapper response: {response}")
    
    if response.startswith("PORT"):
        service_port = int(response.split()[1])
        print(f"Service found on port {service_port}")
        
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((HOST, service_port))
        client.send(b"Hello from client via Port Mapper!")
        response = client.recv(1024)
        print(f"Service response: {response.decode('utf-8')}")
        client.close()
        
    else:
        print("Service not found")
        
except socket.timeout:
    print("Port Mapper not responding")
    
mapper_client.close()