#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

void Run(std::string tcpType)
{
    Config::SetDefault("ns3::TcpL4Protocol::SocketType",
                       TypeIdValue(TypeId::LookupByName(tcpType)));

    NodeContainer nodes;
    nodes.Create(2);

    PointToPointHelper p2p;

    p2p.SetDeviceAttribute("DataRate", StringValue("256Kbps"));
    p2p.SetChannelAttribute("Delay", StringValue("50ms"));

    p2p.SetQueue("ns3::DropTailQueue<Packet>",
                 "MaxSize",
                 QueueSizeValue(QueueSize("10p")));

    NetDeviceContainer devices = p2p.Install(nodes);

    InternetStackHelper stack;
    stack.Install(nodes);

    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = address.Assign(devices);

    uint16_t port = 8080;

    PacketSinkHelper sink("ns3::TcpSocketFactory",
                          InetSocketAddress(Ipv4Address::GetAny(), port));

    ApplicationContainer sinkApp = sink.Install(nodes.Get(1));
    sinkApp.Start(Seconds(0.0));
    sinkApp.Stop(Seconds(30.0));

    OnOffHelper client("ns3::TcpSocketFactory",
                       InetSocketAddress(interfaces.GetAddress(1), port));

    client.SetAttribute("DataRate", StringValue("1Mbps"));
    client.SetAttribute("PacketSize", UintegerValue(1024));

    ApplicationContainer clientApp = client.Install(nodes.Get(0));
    clientApp.Start(Seconds(1.0));
    clientApp.Stop(Seconds(30.0));

    std::string pcapName = "congestion_" + tcpType.substr(5);
    p2p.EnablePcapAll(pcapName);

    Simulator::Stop(Seconds(30.0));
    Simulator::Run();
    Simulator::Destroy();
}

int main(int argc, char *argv[])
{
    std::string mode = "reno";
    CommandLine cmd;
    cmd.AddValue("mode", "reno or cubic", mode);
    cmd.Parse(argc, argv);

    if (mode == "reno")
    {
        Run("ns3::TcpNewReno");
    }
    else if (mode == "cubic")
    {
        Run("ns3::TcpCubic");
    }
    else
    {
        return 1;
    }

    return 0;
}
