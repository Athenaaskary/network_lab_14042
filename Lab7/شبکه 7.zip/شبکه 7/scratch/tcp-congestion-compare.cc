#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

int main(int argc, char *argv[])
{
    std::string tcpType = "TcpReno";

    CommandLine cmd;
    cmd.AddValue("tcpType", "TcpReno or TcpCubic", tcpType);
    cmd.Parse(argc, argv);

    if (tcpType == "TcpReno")
    {
        Config::SetDefault(
            "ns3::TcpL4Protocol::SocketType",
            TypeIdValue(TypeId::LookupByName("ns3::TcpNewReno")));
    }
    else if (tcpType == "TcpCubic")
    {
        Config::SetDefault(
            "ns3::TcpL4Protocol::SocketType",
            TypeIdValue(TypeId::LookupByName("ns3::TcpCubic")));
    }
    else
    {
        std::cout << "Invalid TCP type!" << std::endl;
        return 1;
    }

    NodeContainer nodes;
    nodes.Create(2);

    PointToPointHelper p2p;

    p2p.SetDeviceAttribute("DataRate", StringValue("256Kbps"));
    p2p.SetChannelAttribute("Delay", StringValue("50ms"));

    NetDeviceContainer devices = p2p.Install(nodes);

    Ptr<RateErrorModel> em = CreateObject<RateErrorModel>();
    em->SetAttribute("ErrorRate", DoubleValue(0.01));
    devices.Get(0)->SetAttribute("ReceiveErrorModel", PointerValue(em));

    InternetStackHelper stack;
    stack.Install(nodes);

    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.0");

    Ipv4InterfaceContainer interfaces =
        address.Assign(devices);

    uint16_t port = 8080;

    PacketSinkHelper sinkHelper(
        "ns3::TcpSocketFactory",
        InetSocketAddress(Ipv4Address::GetAny(), port));

    ApplicationContainer sinkApp =
        sinkHelper.Install(nodes.Get(1));

    sinkApp.Start(Seconds(0.0));
    sinkApp.Stop(Seconds(30.0));

    Address sinkAddress(
        InetSocketAddress(
            interfaces.GetAddress(1),
            port));

    BulkSendHelper source(
        "ns3::TcpSocketFactory",
        sinkAddress);

    source.SetAttribute(
        "MaxBytes",
        UintegerValue(0));

    ApplicationContainer sourceApp =
        source.Install(nodes.Get(0));

    sourceApp.Start(Seconds(1.0));
    sourceApp.Stop(Seconds(30.0));

    if (tcpType == "TcpReno")
    {
        p2p.EnablePcapAll("reno-cong");
    }
    else
    {
        p2p.EnablePcapAll("cubic-cong");
    }

    Simulator::Stop(Seconds(30.0));

    Simulator::Run();
    Simulator::Destroy();

    return 0;
}
